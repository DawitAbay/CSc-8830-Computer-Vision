import pytesseract
import cv2

pytesseract.pytesseract.tesseract_cmd = r'/usr/local/bin/tesseract/'
cap = cv2.VideoCapture(
    '/Users/dawitabay/computerVision/Project_OCR/test-video/IMG_0753.MOV')

while True:
    ret, frame = cap.read()

    imgH, imgW, _ = frame.shape

    # Detecting Characters
    boxes = pytesseract.image_to_boxes(frame)

    for box in boxes.splitlines():
        box = box.split(' ')
        # print(box)
        x, y, w, h = int(box[1]), int(box[2]), int(box[3]), int(box[4])
        name = box[0]
        cv2.rectangle(frame, (x, imgH-y), (w, imgH-h), (40, 40, 355), 1)
        cv2.putText(frame, name, (x, imgH-y+25),
                    cv2.FONT_HERSHEY_PLAIN, 1, (40, 40, 55), 2)

    cv2.imshow('Text-Detection-Video', frame)
    key = cv2.waitKey(1)
    if key == 27:
        break

cap.release()
cv2.destroyAllWindows()
